import React, { Component } from 'react';


class Homepage extends Component {
  render() {
    
    if(localStorage.getItem('authenticate') === 'true' ){
      return (      
        <div className="homepageContainer">
          <label className="pull-left">            
          Welcome {localStorage.getItem("username")} to the Homepage</label>
          <img src={require("../Images/astrohands.jpg")} alt="astro hands" />
        </div>
      );
    }else{
      return (      
        <div className="homepageContainer">
          <label className="pull-left">            
            Welcome Dummy user, please login to continue further.
          </label>
          
        </div>
      );
    }
  }
}
export default Homepage;