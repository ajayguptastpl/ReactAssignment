import React, { Component } from 'react';
import {Redirect} from 'react-router-dom';

class Loginpage extends Component {
  constructor(props){
     super(props);
     
     this.state = {
        email: '',
        pwd: '',
        error:'',
        userAuth: false,
        authenticate:false
     }
     
  }

  signUpfunc(){     
     if((this.state.email === localStorage.getItem('username')) && (this.state.pwd === localStorage.getItem('password')))
		{
			localStorage.setItem('authenticate', true)
			this.setState({userAuth: true})
		}
		else
		{
         this.setState({pwd: ''});
         this.setState({email: ''});
			alert("Wrong login credentials.")
		}
  }

   render() {
      if(this.state.userAuth)
		{
		    return (<Redirect to={'/home'}/>)
		}
      return (
      <div className="loginContainer">
         <label className="pull-left">Login Form</label>
         <hr className="col-md-12 pull-left"></hr>
         <form>
         <div className="col-12 pull-left margbtm15">
            <div className="col-4 pull-left inputlabel">Username</div>
            <div className="col-6 pull-left">
               <input 
                  type="text" 
                  className="inputFld" 
                  placeholder="Username" 
                  onChange={event => this.setState({email: event.target.value})}
               />
            </div>
         </div>
         <div className="col-12 pull-left margbtm15">
            <div className="col-4 pull-left inputlabel">Password</div>
            <div className="col-6 pull-left">
               <input 
                  type="password" 
                  className="inputFld" 
                  placeholder="Password" 
                  onChange = {event => this.setState({ pwd: event.target.value})}
               />
            </div>
         </div>
         <div className="col-12 pull-left margbtm15">
            <div className="col-4 pull-left inputlabel">&nbsp;</div>
            <div className="col-6 pull-left">
                <button 
                  type="button" 
                  className="inputBtn" 
                  title="Login"
                  onClick = {() => this.signUpfunc()}
                >
                Login
                </button>
            </div>
         </div>
       </form>
      </div>
    );
  }
}
export default Loginpage;