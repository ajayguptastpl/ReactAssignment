import React, { Component } from 'react';
import {Redirect} from 'react-router-dom';

class Registerpage extends Component {
   constructor(props){
      super(props);
      this.state = {
         username: '',
         emailid: '',
         mobileno: '',
         password:'',
         errors: {},
         redirectTo: false        
      }
      this.submitUserRegistration = this.submitUserRegistration.bind(this);
   }
      handleValidation(){
        
         let errors = {};
         let formIsValid = true;
         
         if(!(this.state.username)){
            formIsValid = false;            
            errors["username"] = "This field is required";
         }
         if(!(this.state.emailid)){
            formIsValid = false;            
            errors["emailid"] = "This field is required";
         }
         if(!(this.state.mobileno)){
            formIsValid = false;            
            errors["mobileno"] = "This field is required";
         }
         if(!(this.state.password)){
            formIsValid = false;            
            errors["password"] = "This field is required";
         }
      console.log(this.state.username);
      this.setState({errors: errors});
      return formIsValid;
   }

  submitUserRegistration(){     
      if(this.handleValidation()){
         localStorage.setItem("username", this.state.username);
         localStorage.setItem("emailid", this.state.emailid);
         localStorage.setItem("mobileno", this.state.mobileno);
         localStorage.setItem("password", this.state.password);
         this.setState({'redirectTo': true}); 
      }
  }
  

render() {
   
   if(this.state.redirectTo)
   {
       return (<Redirect to={'/login'}/>)
   }
    return (
      <div className="loginContainer">
         <label className="pull-left">Registration Form</label>
         <hr className="col-md-12 pull-left"></hr>
         <form className="registerForm">
            <div className="col-12 pull-left margbtm15">
               <div className="col-4 pull-left inputlabel">Username</div>
               <div className="col-6 pull-left">
                  <input type="text" 
                         className="inputFld" 
                         placeholder="Enter Username" 
                         name="username"  
                         onChange = { event => this.setState({username: event.target.value})}
                  />
                  <div className="errormsg" >{this.state.errors["username"]}</div>
               </div>               
            </div>
            <div className="col-12 pull-left margbtm15">
               <div className="col-4 pull-left inputlabel">Email</div>
               <div className="col-6 pull-left">
                  <input type="text" 
                         className="inputFld" 
                         placeholder="Enter Email" 
                         name="emailid" 
                         onChange = { event => this.setState({emailid: event.target.value})}
                  />
                  <div className="errormsg">{this.state.errors["emailid"]}</div>
               </div>               
            </div>
            <div className="col-12 pull-left margbtm15">
               <div className="col-4 pull-left inputlabel">Mobile Number</div>
               <div className="col-6 pull-left">
                  <input type="text" 
                         className="inputFld" 
                         placeholder="Enter Mobile Number" 
                         name="mobileno" 
                         onChange = { event => this.setState({mobileno: event.target.value})}
                  />
                  <div className="errormsg">{this.state.errors["mobileno"]}</div>
               </div>               
            </div>
            <div className="col-12 pull-left margbtm15">
               <div className="col-4 pull-left inputlabel">Password</div>
               <div className="col-6 pull-left">
                  <input type="password" 
                         className="inputFld" 
                         placeholder="Enter Password" 
                         name="password" 
                         onChange = { event => this.setState({password: event.target.value})}
                  />
                  <div className="errormsg">{this.state.errors["password"]}</div>
               </div>               
            </div>
            <div className="col-12 pull-left margbtm15">
               <div className="col-4 pull-left inputlabel">&nbsp;</div>
               <div className="col-6 pull-left">
                   <button type="button" 
                           className="inputBtn" 
                           title="Register" 
                           onClick = {() => this.submitUserRegistration()} 
                   >Register</button>
               </div>
            </div>
         </form>
      </div>
    );
  }
}


export default Registerpage;