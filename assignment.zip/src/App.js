import React, { Component } from 'react';
import './App.css';
import {BrowserRouter , Route, NavLink} from 'react-router-dom';
import Loginpage from './Components/Loginpage';
import Registerpage from './Components/Register';
import Homepage from './Components/Home';


class App extends Component {
  render() {
    return (
      <BrowserRouter>
        <div className="App">
          <header className="app-header">
              <MainMenu />              
          </header>
          
          <Route path="/login" render={ props => <Loginpage {...props} />} />
          <Route path="/signup" render={props => <Registerpage {...props} /> } />
          <Route exact path="/" render={props => <Homepage {...props} /> } /> 
          <Route path="/home" render={props => <Homepage {...props} /> } /> 
        </div>
      </BrowserRouter>
    );
  }
}

const MainMenu = () => {
  return (
    <div className="headerMenu">
      <NavLink to="/home">
        home
      </NavLink>     
      <NavLink to="/login" activeClassName="active">
        Login
      </NavLink>
      <NavLink to="/signup" activeClassName="active">
        Sign Up
      </NavLink>
    </div>
  );
};

export default App;
